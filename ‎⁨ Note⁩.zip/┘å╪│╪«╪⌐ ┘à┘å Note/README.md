# Note
The Final legislator of Tuwaiq camp

User stories:
As a user I can register and login.
The user can add a new note.
User can edit and delete the Note
User can update notes
User can see all other notes posted by another user without access to 'Edit and Delete'.



Markdown

[![wakatime](https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg)](https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37)

HTML

<a href="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37"><img src="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg" alt="wakatime"></a>


Textile
!https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg!:https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37



Rdoc
{<img src="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg" alt="wakatime" />}[https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37]


AsciiDoc
image:https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg["wakatime", link="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37"]


RST
.. image:: https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg



Pod
=for html <a href="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37"><img src="https://wakatime.com/badge/user/04bbea6a-b8a3-4cc3-b8c8-e6d4a61c4547/project/7aa80fb3-e6bc-4238-9b2c-13ba3c684c37.svg"></a>



