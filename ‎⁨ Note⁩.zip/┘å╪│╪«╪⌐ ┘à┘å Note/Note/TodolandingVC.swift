//
//  TodoHomeVC.swift
//  Note
//
//  Created by Nasser Aseeri on 30/05/1443 AH.
//

import UIKit
import Firebase

class TodolandingVC: UIViewController {

    
    @IBOutlet weak var nameLable: UILabel!
    
    @IBOutlet weak var regButt: UIButton!
    
    @IBOutlet weak var logButt: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
